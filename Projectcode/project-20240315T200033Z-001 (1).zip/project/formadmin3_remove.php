<?php 
require_once('connection.php');
if( isset($_POST['id'])&&isset($_POST['action'])){
	$id=$_POST['id'];
	$action=$_POST['action'];
	$sql="Select * from  employee_users where emp_id='$id'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0)
	{
		$sql="Select * from  deduction_employee where emp_id='$id' and type='$action'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0)
	{
		$query = mysqli_query($conn,"UPDATE deduction_employee SET frequency=frequency-1 where emp_id='$id' and type='$action'");
		$sql="Select frequency from  deduction_employee where emp_id='$id' and type='$action'";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_fetch_array($result);
		$frequency = (string) $row['frequency'];
		if($frequency=='0')
		{
			$sql= mysqli_query($conn,"DELETE FROM deduction_employee WHERE emp_id='$id'and type='$action'");	
		
			
		}
		header("Location: formadmin3.html");
	}
	else{
	header("Location: input_wrong.html");
	}
	}
	else{
	
	
	header("Location: input_wrong.html");
	}
}
	?>

	