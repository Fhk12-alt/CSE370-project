<?php 
require_once('connection.php');

if(isset($_POST['id']) && isset($_POST['action'])) {
    $id = $_POST['id'];
    $o = $_POST['action'];

    if($id!="") {
        $sql="Select * from  employee_users where emp_id='$id'";
        $result=mysqli_query($conn,$sql);

        if(mysqli_num_rows($result)==0) {
            header("Location: input_wrong.html");
        }
		else
		{
			if ($o=="permanent")
			{
            $sql="SELECT e.emp_id, e.first_name, e.last_name, e.type, a.base_amount, t.Leaves_taken, t.raise_progress
                FROM employee e 
                JOIN allowance a ON e.emp_id = a.emp_id 
				INNER JOIN $o t ON e.emp_id = t.emp_id AND e.type = '$o' WHERE e.emp_id = '$id' ;";
			}
		else
		{
			$sql="SELECT e.emp_id, e.first_name, e.last_name, e.type, a.base_amount, t.Leaves_taken, t.Progress
                FROM employee e 
                JOIN allowance a ON e.emp_id = a.emp_id 
				INNER JOIN $o t ON e.emp_id = t.emp_id AND e.type = '$o' WHERE e.emp_id = '$id' ;";
		}
	}
			
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                // Output data in a table
                echo "<table style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th style='border: 1px solid black; padding: 8px;'>Employee ID</th><th style='border: 1px solid black; padding: 8px;'>First Name</th><th style='border: 1px solid black; padding: 8px;'>Last Name</th><th style='border: 1px solid black; padding: 8px;'>Type</th><th style='border: 1px solid black; padding: 8px;'>Base Amount</th><th style='border: 1px solid black; padding: 8px;'>Leaves Taken</th><th style='border: 1px solid black; padding: 8px;'>Progress</th></tr>";

while($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td style='border: 1px solid black; padding: 8px;'>".$row["emp_id"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["first_name"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["last_name"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["type"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["base_amount"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["Leaves_taken"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["Progress"]."</td></tr>";
}
echo "</table>";

            }
			
		
    } 
	else {
         if ($o=="permanent"){
            $sql="SELECT e.emp_id, e.first_name, e.last_name, e.type, a.base_amount, t.Leaves_taken, t.raise_progress
                FROM employee e 
                JOIN allowance a ON e.emp_id = a.emp_id 
				INNER JOIN $o t ON e.emp_id = t.emp_id AND e.type = '$o';";
			}
		else
		{
			$sql="SELECT e.emp_id, e.first_name, e.last_name, e.type, a.base_amount, t.Leaves_taken, t.Progress
                FROM employee e 
                JOIN allowance a ON e.emp_id = a.emp_id 
				INNER JOIN $o t ON e.emp_id = t.emp_id AND e.type = '$o';";
		}
		
			
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                // Output data in a table
                echo "<table style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th style='border: 1px solid black; padding: 8px;'>Employee ID</th><th style='border: 1px solid black; padding: 8px;'>First Name</th><th style='border: 1px solid black; padding: 8px;'>Last Name</th><th style='border: 1px solid black; padding: 8px;'>Type</th><th style='border: 1px solid black; padding: 8px;'>Base Amount</th><th style='border: 1px solid black; padding: 8px;'>Leaves Taken</th><th style='border: 1px solid black; padding: 8px;'>Progress</th></tr>";

while($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td style='border: 1px solid black; padding: 8px;'>".$row["emp_id"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["first_name"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["last_name"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["type"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["base_amount"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["Leaves_taken"]."</td><td style='border: 1px solid black; padding: 8px;'>".$row["Progress"]."</td></tr>";
}
echo "</table>";

            
        
    }
	        
	}		
}
?>
