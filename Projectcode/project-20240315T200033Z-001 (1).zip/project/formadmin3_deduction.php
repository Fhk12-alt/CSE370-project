<?php 
require_once('connection.php');
if( isset($_POST['id'])&&isset($_POST['action'])){
	$id=$_POST['id'];
	$action=$_POST['action'];
	$sql="Select * from  employee_users where emp_id='$id'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0)
	{
		$sql="Select * from  deduction_employee where emp_id='$id' and type='$action'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0)
	{
		$query = mysqli_query($conn,"UPDATE deduction_employee SET frequency=frequency+1 where emp_id='$id' and type='$action'");
		header("Location: formadmin3.html");
	}
	else{
	$query = mysqli_query($conn,"INSERT INTO deduction_employee(emp_id, type, frequency) VALUES ('$id','$action','1')");
	header("Location: formadmin3.html");
	}
	}
	else{
	
	
	header("Location: input_wrong.html");
	}
	

	
}
?>
	
	
