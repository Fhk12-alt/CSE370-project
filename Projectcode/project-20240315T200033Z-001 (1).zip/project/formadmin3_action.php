<?php 
require_once('connection.php');
if( isset($_POST['action'])){
	$o=$_POST['action'];
	
	if($o=='deduction'){
	header("Location: formadmin3_deduction.html");
	}
	else if($o=='remove'){
	header("Location: formadmin3_remove.html");
	}
	else{
$sql = "SELECT * FROM requst";
$result = mysqli_query($conn, $sql);

// Check if any rows were returned
if (mysqli_num_rows($result) > 0) {
    // Output data in a table with basic styling
    echo "<table style='border-collapse: collapse;'>";
    echo "<tr><th style='border: 1px solid black; padding: 5px;'>Emp ID</th><th style='border: 1px solid black; padding: 5px;'>Serial</th><th style='border: 1px solid black; padding: 5px;'>Request</th></tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td style='border: 1px solid black; padding: 5px;'>".$row["emp_id"]."</td><td style='border: 1px solid black; padding: 5px;'>".$row["serial"]."</td><td style='border: 1px solid black; padding: 5px;'>".$row["request"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
}
	}
	

	

?>
	
	