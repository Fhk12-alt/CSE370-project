<?php 
require_once('connection.php');
session_start();
if( isset($_SESSION['input_data'])&&isset($_POST['action'])&&isset($_POST['text'])){
	 $input_data = $_SESSION['input_data'];
	$action=$_POST['action'];
	$text=$_POST['text'];
	$sql="Select * from  employee_users where emp_id='$input_data'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0)
	{
		$sql="Select * from  deduction_employee where emp_id='$input_data' and type='$action'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0)
	{
		$sql="Select * from  requst where emp_id='$input_data' ";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0){
		$sql="SELECT MAX(CAST(serial AS UNSIGNED)) AS max_serial FROM requst where emp_id='$input_data'";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_fetch_array($result);
		$max_serial = (int) $row['max_serial'];
		$query = mysqli_query($conn,"INSERT INTO requst(emp_id, serial, request) VALUES ('$input_data','$max_serial'+1,'$text')");
		header("Location: formemp_request.html");
		
	}
	
	else{
		$query = mysqli_query($conn,"INSERT INTO requst(emp_id, serial, request) VALUES ('$input_data','1','$text')");
			header("Location: formemp_request.html");
	}
		
	}
	else{
	
	
	header("Location: input_wrong.html");
	}
}
}
	?>
