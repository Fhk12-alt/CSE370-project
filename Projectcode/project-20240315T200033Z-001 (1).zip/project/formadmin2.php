<?php 
require_once('connection.php');
if(isset($_POST['id'])&&isset( $_POST['action'])){
	$id=$_POST['id'];
	$o=$_POST['action'];
	$sql="Select * from  employee_users where emp_id='$id'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)!=0){
		header("Location: input_wrong.html");
	}
else{
	if($id=="")
	{
		$sql="SELECT e.emp_id, e.first_name, e.last_name, e.type, a.base_amount, t.Leaves_taken, t.Progress
FROM employee e
INNER JOIN allowance a ON e.emp_id = a.emp_id
INNER JOIN type t ON e.emp_id = t.emp_id
	WHERE e.type = '$o'"
	$result = mysql_query($sql);
echo [$result];
			
		
}
}
?>